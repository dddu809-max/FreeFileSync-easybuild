#ifndef VERSION_HEADER_434343489702544325
#define VERSION_HEADER_434343489702544325

namespace zen
{
const wchar_t ffsVersion[] = L"7.0"; //internal linkage!
const wchar_t FFS_VERSION_SEPERATOR = L'.';
}

#endif
